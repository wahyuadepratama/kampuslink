<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kuisioner_1 extends Model
{
    //
}
