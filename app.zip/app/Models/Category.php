<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
  protected $table = "category";

  protected $quarded = [];

  public function eventCategory(){
    return $this->hasMany('App\Models\EventCategory');
  }
}
