<!-- START - Mobile Menu -------------------->
<div class="menu-mobile menu-activated-on-click color-scheme-dark">
  <div class="mm-logo-buttons-w">
    <a class="mm-logo" href="/"><img src="<?php echo e(asset('_admin/img/logo.png')); ?>"><span><?php echo e($organization->name); ?></span></a>
    <div class="mm-buttons">
      <div class="content-panel-open">
        <div class="os-icon os-icon-grid-circles"></div>
      </div>
      <div class="mobile-menu-trigger">
        <div class="os-icon os-icon-hamburger-menu-1"></div>
      </div>
    </div>
  </div>
  <div class="menu-and-user">
    <div class="logged-user-w">
      <div class="avatar-w">
        <img alt="" src="<?php echo e(asset('storage/avatar/'. Auth::user()->photo_profile)); ?> ">
      </div>
      <div class="logged-user-info-w">
        <div class="logged-user-name">
          <?php echo e(Auth::user()->fullname); ?>

        </div>
        <div class="logged-user-role">
          <?php echo e(Auth::user()->checkRoleUserOrganization($organization->id)); ?>

        </div>
      </div>
    </div>
    <!-- START - Mobile Menu List -------------------->
    <ul class="main-menu">
      <li>
        <a href="<?php echo e(url('organization/'. $organization->instagram)); ?>">
          <div class="icon-w">
            <div class="os-icon os-icon-layout"></div>
          </div>
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('organization/'. $organization->instagram)); ?>">
          <div class="icon-w">
            <div class="os-icon os-icon-ui-49"></div>
          </div>
          <span>Profile</span>
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('organization/'. $organization->instagram). '/members'); ?>">
          <div class="icon-w">
            <div class="os-icon os-icon-users"></div>
          </div>
          <span>Members</span>
        </a>
      </li>
      <li>
        <a href="event.php">
          <div class="icon-w">
            <div class="os-icon os-icon-file-text"></div>
          </div>
          <span>Event</span>
        </a>
      </li>
    </ul>
    <!-- END - Mobile Menu List -------------------->
  </div>
</div>
<!-- END - Mobile Menu -------------------->
