<?php echo $__env->make('partial/_superadmin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<ul class="breadcrumb">
  <li class="breadcrumb-item">
    <span>Dashboard</span>
  </li>
  <li class="breadcrumb-item">
    <span>Faculty</span>
  </li>
</ul>

<div class="content-panel-toggler">
  <i class="os-icon os-icon-grid-squares-22"></i><span>Sidebar</span>
</div>
<div class="content-i">
  <div class="content-box">

    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <?php echo e($message); ?>

      </div>
    <?php endif; ?>

    <a href="#" data-target="#add" data-toggle="modal" class="btn btn-primary">+ Add New Faculty</a><br>
    <div aria-labelledby="add" class="modal fade" id="add" role="dialog" tabindex="-1" style="display: none;" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="add">
              Add New Faculty
            </h5>
            <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true"> ×</span></button>
          </div>
          <form action="<?php echo e(url('admin/faculty/store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

          <div class="modal-body">
              <div class="form-group">
                <label for="">Name</label>
                <input class="form-control" type="text" name="name">
              </div>
              <div class="form-group">
                <label for="">University</label>
                <?php $campus = App\Models\Campus::all(); ?>
                <select class="form-control" name="campus_id">
                  <?php $__currentLoopData = $campus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($c->id); ?>"> <?php echo e($c->name); ?> </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-primary" type="submit"> Add</button>
          </div>
          </form>
        </div>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped table-lightfont">
        <thead>
          <tr>
            <th>
              Name
            </th>
            <th>
              University
            </th>
            <th>
              Action
            </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <?php echo e($value->name); ?>

            </td>
            <td>
              <?php if(isset($value->campus->name)): ?>
                <?php echo e($value->campus->name); ?>

              <?php else: ?>
                <div style="color:red">Kampus di Blokir</div>
              <?php endif; ?>
            </td>
            <td>
              <a href="<?php echo e(url('admin/faculty/destroy/'. $value->id)); ?>" onclick="return confirm('Semua data jurusan dan user yang ada di kampus ini akan ikut terhapus!! Apakah kamu yakin?')" class="btn btn-sm btn-danger">Destroy</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>

  </div>
</div>
</div>
</div>
<div class="display-type"></div>
</div>

  <?php echo $__env->make('partial/_superadmin_script_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
