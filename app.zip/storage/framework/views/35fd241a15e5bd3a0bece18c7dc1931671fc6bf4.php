<?php echo $__env->make('partial/_guest_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!--================Home Banner Area =================-->
	<section class="new_banner_area">
		<div class="banner-img bg-overlay-39">
			<div class="container">
				<h1 style="margin-top:3%">Proses Pembayaran</h1>
				<ul>
          <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
					<li>Process</li>
        </ul>
			</div>
			<div class="box-position"><img src="<?php echo e(url('client/img/banner/banner-bg.jpg')); ?>" alt=""> </div>
		</div>
	</section>
	<!--================End Home Banner Area =================-->

	<!--================Cart Area =================-->
	<section class="cart_area">
		<div class="container">
			<?php if($message = Session::get('error')): ?>
				<div class="alert alert-danger">
					<?php echo e($message); ?>

				</div>
			<?php endif; ?>
			<div class="cart_inner">
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">Event</th>
								<th scope="col">Jenis</th>
								<th scope="col">Harga</th>
								<th scope="col">Jumlah</th>
								<th scope="col">Total</th>
							</tr>
						</thead>
            <form id="my_form" action="<?php echo e(url('event/' .$slug)); ?>/process" method="post">
            <?php echo e(csrf_field()); ?>

						<tbody>
              <?php $limit = false; ?>
              <?php $__currentLoopData = $subEventTicket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td>
                  <?php if($limit == false): ?>
									<div class="media">
										<div class="d-flex">
											<?php if(isset($key->subEvent->event->name)): ?>
											<?php echo e($key->subEvent->event->name); ?> (<?php echo e($key->subEvent->name); ?>)
											<?php else: ?>
											<?php echo e($key->subEvent->name); ?>

											<?php endif; ?>
										</div>
									</div>
                  <?php endif; ?>
								</td>
								<td>
									<span class="jenis"><?php echo e($key->type); ?></span>
								</td>
								<td>
									<h5>Rp <?php echo e(number_format(($key->price),0,',','.')); ?></h5>
								</td>
								<td>
									<div class="product_count">
                    <input type="number" name="qty[<?php echo e($key->type); ?>]" id='sst<?php echo e($key->id); ?>' maxlength="12" value="0" title="Quantity:" class="input-text qty<?php echo e($key->id); ?>">
										<input type="hidden" id="qty<?php echo e($key->id); ?>">
										<button onclick="var result = document.getElementById('sst<?php echo e($key->id); ?>'); var sst<?php echo e($key->id); ?> = result.value; if( !isNaN( sst<?php echo e($key->id); ?> )) result.value++;return false;"
										 class="increase items-count btn-plus-<?php echo e($key->id); ?>" type="button">
											<i class="lnr lnr-chevron-up"></i>
										</button>
										<button onclick="var result = document.getElementById('sst<?php echo e($key->id); ?>'); var sst<?php echo e($key->id); ?> = result.value; if( !isNaN( sst<?php echo e($key->id); ?> ) &amp;&amp; sst<?php echo e($key->id); ?> > 0 ) result.value--;return false;"
										 class="reduced items-count btn-min-<?php echo e($key->id); ?>" type="button">
											<i class="lnr lnr-chevron-down"></i>
										</button>
									</div>
								</td>
								<td>
									<h5>Rp <span id="total<?php echo e($key->id); ?>">0</span></h5>
								</td>
							</tr>

              <script type="text/javascript">
                $(document).ready(function(){
                  // reguler
                  $('#sst<?php echo e($key->id); ?>').on("keyup", function(){

                      var qty = [];
                      var reguler = [];
                      var total = [];
                      qty['<?php echo e($key->id); ?>'] = $('#sst<?php echo e($key->id); ?>').val();
                      reguler['<?php echo e($key->id); ?>'] = <?php echo e($key->price); ?>;
                      total['<?php echo e($key->id); ?>'] = qty['<?php echo e($key->id); ?>'] * reguler['<?php echo e($key->id); ?>'];
                      $('#total<?php echo e($key->id); ?>').text(new Intl.NumberFormat('en-CA', {style: 'decimal'}).format(total['<?php echo e($key->id); ?>']));
                      $('#qty<?php echo e($key->id); ?>').val(total['<?php echo e($key->id); ?>']);

                      var subtotal = 0;
                      <?php foreach($subEventTicket as $data){ ?>
                        qty['<?php echo e($data->id); ?>'] = parseInt($('#qty<?php echo e($data->id); ?>').val());
                        if (!qty['<?php echo e($data->id); ?>']) {
                          qty['<?php echo e($data->id); ?>'] = 0;
                        }
                        subtotal = subtotal + qty['<?php echo e($data->id); ?>'];
                      <?php } ?>

                      $('#subtotal').text(new Intl.NumberFormat('en-CA', {style: 'decimal'}).format(subtotal));

                  });

                  $('.btn-plus-<?php echo e($key->id); ?>').click(function(){

                    var qty = [];
                    var reguler = [];
                    var total = [];
                    qty['<?php echo e($key->id); ?>'] = $('#sst<?php echo e($key->id); ?>').val();
                    reguler['<?php echo e($key->id); ?>'] = <?php echo e($key->price); ?>;
                    total['<?php echo e($key->id); ?>'] = qty['<?php echo e($key->id); ?>'] * reguler['<?php echo e($key->id); ?>'];
                    $('#total<?php echo e($key->id); ?>').text(new Intl.NumberFormat('en-CA', {style: 'decimal'}).format(total['<?php echo e($key->id); ?>']));
                    $('#qty<?php echo e($key->id); ?>').val(total['<?php echo e($key->id); ?>']);

                    var subtotal = 0;
                    <?php foreach($subEventTicket as $data){ ?>
                      qty['<?php echo e($data->id); ?>'] = parseInt($('#qty<?php echo e($data->id); ?>').val());
                      if (!qty['<?php echo e($data->id); ?>']) {
                        qty['<?php echo e($data->id); ?>'] = 0;
                      }
                      subtotal = subtotal + qty['<?php echo e($data->id); ?>'];
                    <?php } ?>

                    $('#subtotal').text(new Intl.NumberFormat('en-CA', {style: 'decimal'}).format(subtotal));

                  });

                  $('.btn-min-<?php echo e($key->id); ?>').click(function(){

                    var qty = [];
                    var reguler = [];
                    var total = [];
                    qty['<?php echo e($key->id); ?>'] = $('#sst<?php echo e($key->id); ?>').val();
                    reguler['<?php echo e($key->id); ?>'] = <?php echo e($key->price); ?>;
                    total['<?php echo e($key->id); ?>'] = qty['<?php echo e($key->id); ?>'] * reguler['<?php echo e($key->id); ?>'];
                    $('#total<?php echo e($key->id); ?>').text(new Intl.NumberFormat('en-CA', {style: 'decimal'}).format(total['<?php echo e($key->id); ?>']));
                    $('#qty<?php echo e($key->id); ?>').val(total['<?php echo e($key->id); ?>']);

                    var subtotal = 0;
                    <?php foreach($subEventTicket as $data){ ?>
                      qty['<?php echo e($data->id); ?>'] = parseInt($('#qty<?php echo e($data->id); ?>').val());
                      if (!qty['<?php echo e($data->id); ?>']) {
                        qty['<?php echo e($data->id); ?>'] = 0;
                      }
                      subtotal = subtotal + qty['<?php echo e($data->id); ?>'];
                    <?php } ?>

                    $('#subtotal').text(new Intl.NumberFormat('en-CA', {style: 'decimal'}).format(subtotal));

                  });

                });
              </script>

                <?php $limit = true; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<td>

								</td>
								<td>

								</td>
								<td>

								</td>
								<td>
									<h5>Subtotal</h5>
								</td>
								<td>
									<h5>Rp <span id="subtotal">0</span></h5>
								</td>
							</tr>
							<tr class="out_button_area">
								<td>

								</td>
								<td>

								</td>
								<td>

								</td>
								<td>

								</td>
								<td align="right">
									<div class="checkout_btn_inner">
										<!-- <a class="gray_btn" href="#">Continue Shopping</a> -->
                    <a class="main_btn" href="javascript:{}" onclick="document.getElementById('my_form').submit();" id="proses_btn">Proceed to checkout</a>
									</div>
								</td>
							</tr>
						</tbody>
            </form>
					</table>
				</div>
			</div>
		</div>
	</section>
	<!--================End Cart Area =================-->

	<!--================ start footer Area  =================-->
	<?php echo $__env->make('partial/_guest_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!--================ End footer Area  =================-->




<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('client/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/stellar.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/lightbox/simpleLightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/nice-select/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/isotope/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/isotope/isotope-min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/counter-up/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/counter-up/jquery.counterup.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/theme.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('#proses_btn').('class','btn-block');
});
</script>
</body>

</html>
