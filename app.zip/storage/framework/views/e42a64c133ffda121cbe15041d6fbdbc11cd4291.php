<section class="subscription-area section_gap" style="padding-top: 5%; padding-bottom: 5%; background-color: #f0f0f0;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="section-title text-center">
          <h2>Dapatkan info terbaru dari kami</h2>
        </div>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div id="mc_embed_signup">
          <form target="_blank" novalidate action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&id=92a4423d01"
           method="get" class="subscription relative">
            <input type="email" name="EMAIL" placeholder="alamat email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email address'"
             required="">
            <button type="submit" class="newsl-btn">GABUNG</button>
            <div class="info"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
