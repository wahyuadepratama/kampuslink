<?php echo $__env->make('partial/_superadmin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<ul class="breadcrumb">
  <li class="breadcrumb-item">
    <span>Dashboard</span>
  </li>
  <li class="breadcrumb-item">
    <span>University</span>
  </li>
</ul>

<div class="content-panel-toggler">
  <i class="os-icon os-icon-grid-squares-22"></i><span>Sidebar</span>
</div>
<div class="content-i">
  <div class="content-box">

    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <?php echo e($message); ?>

      </div>
    <?php endif; ?>

    <a href="#" data-target="#add" data-toggle="modal" class="btn btn-primary">+ Add New University</a><br>
    <div aria-labelledby="add" class="modal fade" id="add" role="dialog" tabindex="-1" style="display: none;" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="add">
              Add New University
            </h5>
            <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true"> ×</span></button>
          </div>
          <form action="<?php echo e(url('admin/university/store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

          <div class="modal-body">
              <div class="form-group">
                <label for="">Name</label>
                <input class="form-control" type="text" name="name">
              </div>
              <div class="form-group">
                <label for="">Location</label>
                <input class="form-control" type="text" name="location">
              </div>
              <div class="form-group">
                <label for="">Description</label>
                <textarea class="form-control" name="description" rows="4" cols="40"></textarea>
              </div>
              <div class="form-group">
                <label for="">Background Color</label>
                <input class="form-control" type="text" name="background_color">
              </div>
              <div class="form-group">
                <label for="">Logo</label>
                <input type="file" name="logo" class="form-control">
              </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-primary" type="submit"> Add</button>
          </div>
          </form>
        </div>
      </div>
    </div>

    <div class="table-responsive">
          <table class="table table-lightborder">
            <thead>
              <tr>
                <th>
                  Logo
                </th>
                <th>
                  Name
                </th>
                <th>
                  Location
                </th>
                <th>
                  Description
                </th>
                <th>
                  Background Color
                </th>
                <th>
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <img src="<?php echo e(asset('storage/university/' . $value->logo)); ?>" width="50px" style="border-radius:50%">
                </td>
                <td>
                  <?php echo e($value->name); ?>

                </td>
                <td>
                  <?php echo e($value->location); ?>

                </td>
                <td>
                  <?php echo e($value->description); ?>

                </td>
                <td>
                  <div class="status-pill" style="background-color:<?php echo $value->background_color; ?>" data-toggle="tooltip" data-original-title="" title=""></div>
                </td>
                <td>
                  <a href="<?php echo e(url('admin/university/destroy/'. $value->id)); ?>" onclick="return confirm('Semua data fakultas, jurusan, event dan user yang ada di kampus ini akan ikut terhapus!! Apakah kamu yakin?')" class="btn btn-sm btn-danger">Destroy</a>
                  <a href="#" class="btn btn-sm btn-primary" data-target="#edit<?php echo e($value->id); ?>" data-toggle="modal">Edit</a>
                  <div aria-labelledby="edit<?php echo e($value->id); ?>" class="modal fade" id="edit<?php echo e($value->id); ?>" role="dialog" tabindex="-1" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="edit<?php echo e($value->id); ?>">
                            Edit <?php echo e($value->name); ?>

                          </h5>
                          <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true"> ×</span></button>
                        </div>
                        <form action="<?php echo e(url('admin/university/update/'. $value->id)); ?>" method="post" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>

                        <div class="modal-body">
                            <div class="form-group">
                              <label for="">Name</label>
                              <input class="form-control" type="text" value="<?php echo e($value->name); ?>" name="name">
                            </div>
                            <div class="form-group">
                              <label for="">Location</label>
                              <input class="form-control" type="text" value="<?php echo e($value->location); ?>" name="location">
                            </div>
                            <div class="form-group">
                              <label for="">Description</label>
                              <textarea class="form-control" name="description" rows="4" cols="40"><?php echo e($value->description); ?></textarea>
                            </div>
                            <div class="form-group">
                              <label for="">Background Color</label>
                              <input class="form-control" type="text" value="<?php echo e($value->background_color); ?>" name="background_color">
                            </div>
                            <div class="form-group">
                              <label for="">Logo</label>
                              <input type="file" name="logo" class="form-control">
                            </div>
                        </div>
                        <div class="modal-footer">
                          <button class="btn btn-primary" type="submit"> Save changes</button>
                        </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>


  </div>
</div>
</div>
</div>
<div class="display-type"></div>
</div>

  <?php echo $__env->make('partial/_superadmin_script_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
