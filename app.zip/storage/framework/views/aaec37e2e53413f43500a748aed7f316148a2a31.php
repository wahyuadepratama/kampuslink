<?php echo $__env->make('partial/_admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <ul class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('organization/'. $organization->instagram)); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item">
            <span>Dana Terkumpul</span>
          </li>
        </ul>

        <div class="content-i">
          <div class="content-box">
            <div class="row" style="margin-bottom: 5%">
              <div class="col-md-6"></div>
              <div class="col-md-6">
                <input type="text" class="form-control" placeholder="Cari Event" id="transaction" onkeyup="searchJs()">
              </div>
            </div>
            <div id="myUL">
            <?php $__currentLoopData = $subEvent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span>
              <b>
                <div style="display:none">
                  <?php echo e($key->name); ?>

                </div>
                <div class="element-wrapper">
                    <h6 class="element-header">
                        <?php echo e($key->name); ?>

                    </h6>
                    <div class="invoice-body">
                      <div class="invoice-desc">
                        <div class="desc-label">
                          #<?php echo e($key->id); ?>

                        </div>
                        <div class="desc-value">
                          <small><?php echo e($key->updated_at); ?></small>
                        </div>
                      </div>
                      <div class="invoice-table">
                        <table class="table">
                          <thead>
                            <tr>
                              <th>
                                Transaksi
                              </th>
                              <th>
                                Tiket
                              </th>
                              <th class="text-right">
                                Total
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $transaction = \App\Models\Transaction::where('sub_event_id', $key->id)->where('status', 'Pembayaran Berhasil')->get(); ?>
                            <?php $bigTotal = 0; ?>
                            <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td>
                                #<?php echo e($data->unique_code); ?>

                              </td>
                              <td>
                                <?php
                                  $ticket = \App\Models\Ticket::where('transaction_id', $data->id)->get();
                                  $total = 0;
                                  foreach($ticket as $price){
                                    $total = $total + $price->price;
                                  }
                                ?>
                                <?php echo e(count($ticket)); ?>

                              </td>
                              <td class="text-right">
                                Rp <?php echo e(number_format(($total),0,',','.')); ?>

                                <?php $bigTotal = $bigTotal + $total; ?>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                          <tfoot>
                            <tr>
                              <td>
                                Total
                              </td>
                              <td class="text-right" colspan="2">
                                Rp <?php echo e(number_format(($bigTotal),0,',','.')); ?>

                              </td>
                            </tr>
                          </tfoot>
                        </table>
                        <div class="terms">
                          <div class="terms-content">
                            Note: <i>Penarikan dana hanya dapat dilakukan oleh admin <?php echo e($organization->name); ?>. Info lebih lanjut hubungi: <a href="http://wa.me/6281371321971">Admin KampusLink</a>.</i>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
              </b>
            </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

      <div class="display-type"></div>
    </div>

    <script>
      function searchJs() {
        // Declare variables
        var input, filter, ul, li, a, i, txtValue;
        input = document.getElementById('transaction');
        filter = input.value.toUpperCase();
        ul = document.getElementById("myUL");
        li = ul.getElementsByTagName('span');

        // Loop through all list items, and hide those who don't match the search query
        for (i = 0; i < li.length; i++) {
          a = li[i].getElementsByTagName("b")[0];
          txtValue = a.textContent || a.innerText;
          if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
          } else {
            li[i].style.display = "none";
          }
        }
      }
    </script>

    <?php echo $__env->make('partial/_admin_script_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </body>
</html>
