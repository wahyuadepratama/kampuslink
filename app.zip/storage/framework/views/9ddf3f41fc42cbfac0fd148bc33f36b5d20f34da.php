<?php echo $__env->make('partial/_admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <ul class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(url('organization/'. $organization->instagram)); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <span>Profil</span>
            </li>
          </ul>

          <div class="content-box">
            <div class="element-wrapper">
              <div class="user-profile">
                <div class="up-head-w" style="background-image:url(<?php echo e(asset('storage/organization_cover/'. $organization->photo_cover)); ?>)">
                  <div class="up-main-info">
                    <div class="user-avatar-w">
                      <div class="user-avatar">
                        <img alt="" src="<?php echo e(asset('storage/organization/'. $organization->photo_profile)); ?>">
                      </div>
                    </div>
                    <h1 class="up-header">
                      <?php echo e($organization->name); ?>

                    </h1>
                    <h5 class="up-sub-header">
                      <?php echo e($organization->campus->name); ?>

                    </h5>
                  </div>
                  <svg class="decor" width="842px" height="219px" viewBox="0 0 842 219" preserveAspectRatio="xMaxYMax meet" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g transform="translate(-381.000000, -362.000000)" fill="#FFFFFF"><path class="decor-path" d="M1223,362 L1223,581 L381,581 C868.912802,575.666667 1149.57947,502.666667 1223,362 Z"></path></g></svg>
                </div>
                <div class="up-controls">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="value-pair">
                        <div class="label">
                          Status:
                        </div>
                        <?php if(Auth::user()->isOnline(Auth::user()->id)): ?>
                        <div class="value badge badge-pill badge-success">
                          Online
                        </div>
                        <?php else: ?>
                        <div class="value badge badge-pill badge-danger">
                          Offline
                        </div>
                        <?php endif; ?>
                      </div>
                      <div class="value-pair">
                        <div class="label">
                          Bergabung sejak:
                        </div>
                        <div class="value">
                          <?php echo e(\Carbon\Carbon::parse(Auth::user()->created_at)->format('Y')); ?>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="up-contents">
                  <div class="os-tabs-w">
                    <div class="os-tabs-controls">
                      <ul class="nav nav-tabs bigger">
                        <li class="nav-item">
                          <a class="nav-link active" data-toggle="tab" href="#tab_overview">Profile</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-toggle="tab" href="#tab_sales">Edit Profil</a>
                        </li>
                      </ul>
                    </div>
                    <div class="tab-content">
                      <div class="tab-pane active" id="tab_overview">
                        <div class="timed-activities padded">
                          <p>
                            <?php echo $organization->description; ?>
                          </p>
                          <div class="row" style="margin-top: 2%">
                            <div class="col-md-3">
                              <button class="mr-2 mb-2 btn btn-success form-control" type="button" data-container="body" data-content="Line: <?php echo e($organization->line); ?>" data-placement="top" data-toggle="popover">LINE</button>
                            </div>
                            <div class="col-md-3">
                              <button class="mr-2 mb-2 btn btn-info form-control" type="button" style="background-color: #3b5998;border-color:#3b5998;color:white" data-container="body" data-content="Facebook: <?php echo e($organization->facebook); ?>" data-placement="top" data-toggle="popover">Facebook</button>
                            </div>
                            <div class="col-md-3">
                              <button class="mr-2 mb-2 btn btn-info form-control" type="button" style="background-image: linear-gradient(to right, rgb(76, 88, 206), #609, rgb(210, 81, 114), rgb(235, 120, 28), rgb(245, 211, 112));border-color:#fff;color:white" data-container="body" data-content="Instagram: <?php echo e($organization->instagram); ?>" data-placement="bottom" data-toggle="popover">
                                Instagram</button>
                            </div>
                            <div class="col-md-3">
                              <button class="mr-2 mb-2 btn btn-info form-control" type="button" style="background-color: #5eca5e;border-color:#5eca5e;color:white" data-container="body" data-content="WhatsApp: <?php echo e($organization->whatsapp); ?>" data-placement="bottom" data-toggle="popover">
                                WhatsApp</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="tab-pane" id="tab_sales">
                        <div class="row">
                          <div class="col-sm-9">
                            <div class="element-wrapper">
                              <div class="element-box">
                                <form action="<?php echo e(url('organization/'. $organization->instagram .'/profile')); ?>" method="post" id="formValidate" enctype="multipart/form-data">
                                  <?php if( count( $errors ) > 0 ): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger">
                                      <?php echo e($error); ?>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                                  <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success">
                                      <?php echo e($message); ?>

                                    </div>
                                  <?php endif; ?>
                                  <div class="element-info">
                                    <div class="element-info-with-icon">
                                      <div class="element-info-icon">
                                        <div class="os-icon os-icon-wallet-loaded"></div>
                                      </div>
                                      <div class="element-info-text">
                                        <div class="element-inner-desc">
                                          Lengkapi profilmu agar mereka semua tau info pribadi organisasi kamu. Semua form yang bertanda  <code class="highlighter-rouge">*</code> wajib di isi
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <label for=""> Nama <code class="highlighter-rouge">*</code></label>
                                    <input name="name" value="<?php echo e($organization->name); ?>" class="form-control" data-error="Nama wajib diisi" placeholder="nama" required="required" type="text">
                                    <div class="help-block form-text with-errors form-control-feedback"></div>
                                  </div>
                                  <div class="form-group">
                                    <label for="">Nomor Telp/HP <code class="highlighter-rouge">*</code></label>
                                    <input name="phone" value="<?php echo e($organization->phone); ?>" required="required" class="form-control" placeholder="08xxxxx" type="number">
                                    <div class="help-block form-text with-errors form-control-feedback"></div>
                                  </div>
                                  <div class="form-group">
                                    <label for="">Facebook</label>
                                    <input name="facebook" value="<?php echo e($organization->facebook); ?>" class="form-control" placeholder="URL Facebook" type="text">
                                    <div class="help-block form-text with-errors form-control-feedback"></div>
                                  </div>
                                  <div class="form-group">
                                    <label for="">ID Line</label>
                                    <input name="line" value="<?php echo e($organization->line); ?>" class="form-control" placeholder="ID Line" type="text">
                                    <div class="help-block form-text with-errors form-control-feedback"></div>
                                  </div>
                                  <div class="form-group">
                                    <label for="">Nomor WA</label>
                                    <input name="whatsapp" value="<?php echo e($organization->whatsapp); ?>" class="form-control" placeholder="08xxxxx" type="number">
                                    <div class="help-block form-text with-errors form-control-feedback"></div>
                                  </div>
                                  <div class="form-group">
                                    <label> Deskripsi <code class="highlighter-rouge">*</code></label>
                                    <textarea name="description" id="ckeditor1" required="required" class="form-control" rows="6"><?php echo e($organization->description); ?></textarea>
                                  </div>
                                  <div class="form-group">
                                    <label> Cover Foto</label>
                                    <input type="file" name="cover" class="form-control-file">
                                  </div>
                                  <?php echo e(csrf_field()); ?>

                                  <input class="btn btn-primary" type="submit"> </input>
                                </form>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="tab-pane" id="tab_conversion"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="content-panel">
            <div class="content-panel-close">
              <i class="os-icon os-icon-close"></i>
            </div>
          </div>

        </div>
      </div>
    </div>
    <div class="display-type"></div>
  </div>

  <?php echo $__env->make('partial/_admin_script_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
