<?php echo $__env->make('partial/_guest_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--================Order Details Area =================-->

	<section class="order_details p_120">
		<div class="container">

			<?php if($status == "Konfirmasi Tiket"): ?>
			<div class="alert alert-primary" role="alert">
			  Silahkan isi nama pemilik untuk masing - masing tiket. Nama pada tiket juga akan digunakan oleh organisasi untuk membuat sertifikat.
			</div>
      <?php elseif($status == "Menunggu Pembayaran"): ?>
      <div class="alert alert-info" role="alert">
			  Terima Kasih. e-tiket kamu akan kami proses setelah melakukan pembayaran.
			</div>
      <?php elseif($status == "Pembayaran Dibatalkan"): ?>
      <div class="alert alert-warning" role="alert">
			  Maaf. e-tiket kamu tidak kami proses karna melewati jangka waktu pembayaran.
			</div>
      <?php elseif($status == "Diproses"): ?>
      <div class="alert alert-primary" role="alert">
			  Mohon tunggu, tiket kamu sedang diproses.
			</div>
      <?php elseif($status == "Ditolak"): ?>
      <div class="alert alert-danger" role="alert">
			  Maaf, pemesanan tiket kamu dibatalkan! Info lebih lanjut hubungi kami.
			</div>
      <?php elseif($status == "Pembayaran Berhasil"): ?>
      <div class="alert alert-success" role="alert">
			  Terima kasih telah menggunakan KampusLink untuk pemesanan tiket, jika ada saran atau komentar tentang kami, silahkan kirimkan pesan melalui email <i>tanyakami@kampuslink.com</i> .
			</div>
      <?php endif; ?>

			<div class="row" style="margin-top: 5%">
				<div class="col-md-4">
					<div class="row order_d_inner">
							<div class="details_item">
								<h4>Info Pembayaran</h4>
								<ul class="list">
									<li>
										<a href="#">
											<span>Kode Pembayaran</span> : #<?php echo e($transaction->unique_code); ?></a>
									</li>
									<li>
										<a href="#">
											<span>Tanggal Pemesanan</span> : <?php echo \Carbon\Carbon::parse($transaction->created_at)->format('l, d F Y'); ?></a>
									</li>
									<li>
										<a href="#">
											<span>Total</span> : Rp <?php echo e(number_format(($total),0,',','.')); ?></a>
									</li>
									<?php if($status == "Pembayaran Berhasil"): ?>
									<br><input type="submit" onclick="printDiv('printableArea')" value="Download Ticket" class="btn btn-success form-control">
									<?php endif; ?>
									<?php if($status == "Diproses" | $status == "Pembayaran Berhasil"): ?>  <?php else: ?>
									<li>
										<a href="#">
											<span>Waktu Pembayaran</span> : <div id="waktu_pembayaran"></div></a>
									</li>
									<?php endif; ?>
									<br>
								</ul>
							</div>
					</div>
				</div>

				<?php if($status == "Konfirmasi Tiket"): ?>

				<div class="col-md-8 order_details_div">
					<div class="order_details_table">
						<h2>Detail Tiket <?php echo e($transaction->subEvent->name); ?></h2>
						<div class="table-responsive">
							<table class="table" width="100%">
								<thead>
									<tr>
										<th scope="col">Jenis</th>
										<th scope="col">Total</th>
									</tr>
								</thead>
								<tbody>
									<form class="" action="<?php echo e(url('transaction/'. $transaction->unique_code . '/confirm')); ?>" method="post">
									<?php echo e(csrf_field()); ?>


									<?php $ticket = \App\Models\Ticket::where('transaction_id', $transaction->id)->get(); ?>
									<?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($data->type); ?></td>
										<td>Rp <?php echo e(number_format(($data->price),0,',','.')); ?></td>
										<td>
											<input type="text" name="value[<?php echo e($data->id); ?>]" class="form-control" placeholder="Nama Pemilik Tiket">
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td colspan="2">
										</td>
										<td>
											<input type="submit" value="Konfirmasi" class="form-control btn btn-sm btn-success">
										</td>
									</tr>
									</form>
								</tbody>
							</table>
						</div>
					</div>
				</div>

				<?php elseif($status == "Ditolak" | $status == "Pembayaran Dibatalkan"): ?>

				<div class="col-md-8 order_details_div">
					<div class="order_details_table">
						<h2>Detail Tiket <?php echo e($transaction->subEvent->name); ?></h2>
						<div class="table-responsive">
							<table class="table" width="100%">
								<thead>
									<tr>
										<th scope="col">Jenis</th>
										<th scope="col">Total</th>
									</tr>
								</thead>
								<tbody>
									<?php $ticket = \App\Models\Ticket::where('transaction_id', $transaction->id)->get(); ?>

									<?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($data->type); ?></td>
										<td>Rp <?php echo e(number_format(($data->price),0,',','.')); ?></td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<tr>
										<td>
											<h4>Total SEMUA</h4>
										</td>
										<td>
											<p>Rp <?php echo e(number_format(($total),0,',','.')); ?></p>
										</td>
										<td></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div><br><br>

				<?php else: ?>

				<div class="col-md-8 order_details_div">
					<div class="order_details_table">
						<h2>Detail Tiket <?php echo e($transaction->subEvent->name); ?></h2>
						<div class="table-responsive">
							<table class="table" width="100%">
								<thead>
									<tr>
										<th scope="col">Jenis</th>
										<th scope="col">Total</th>
										<th scope="col">Nama</th>
									</tr>
								</thead>
								<tbody>
									<?php $ticket = \App\Models\Ticket::where('transaction_id', $transaction->id)->get(); ?>

									<?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($data->type); ?></td>
										<td>Rp <?php echo e(number_format(($data->price),0,',','.')); ?></td>
										<td><?php echo e($data->owner); ?></td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<tr>
										<td>
											<h4>Total SEMUA</h4>
										</td>
										<td>
											<p>Rp <?php echo e(number_format(($total),0,',','.')); ?></p>
										</td>
										<td></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>

					<?php if($status == "Menunggu Pembayaran"): ?>
					<div class="order_details_table">
						<h2>Proses Pembayaran</h2>
						<div class="table-responsive">
							<table class="table" width="100%">
								<thead>
									<tr>
										<th scope="col">Bank</th>
										<th scope="col">A/N</th>
										<th scope="col">No Rekening</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td><img src="<?php echo e(asset('client/img/icon/mandiri.png')); ?>" width="90px"></td>
										<td>Badu Badui</td>
										<td>6218721183298</td>
									</tr>
									<tr>
										<td><img src="<?php echo e(asset('client/img/icon/bni.png')); ?>" width="90px"></td>
										<td>Badu Badui</td>
										<td>6218721183298</td>
									</tr>
									<tr>
										<td><img src="<?php echo e(asset('client/img/icon/bri.png')); ?>" width="90px"></td>
										<td>Badu Badui</td>
										<td>6218721183298</td>
									</tr>
									<tr>
										<td colspan="3">
											<form class="" action="<?php echo e(url('/transaction/'. $transaction->unique_code . '/proof/upload')); ?>" method="post" enctype="multipart/form-data">
												<input type="file" name="proof" class="form-control-file"><br> <?php echo e(csrf_field()); ?>

												<input type="submit" class="btn btn-sm btn-success form-control" value="Upload">
											</form>
										</td>
									</tr>
									<tr>
										<td colspan="3">
												<li>Lakukan pembayaran ke salah satu rekening di atas.</li>
												<li>Upload bukti pembayaran pada form di atas atau</li>
												<li>Upload bukti pembayaran melalui nomor WhatsApp berikut: 0812XXXXX</li>
												<li>Pembayaran anda akan segera diproses setelah anda melakukan konfirmasi</li>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
					<?php endif; ?>

				</div>

				<?php endif; ?>

			</div>

		<?php if($status == "Pembayaran Berhasil"): ?>

			<div id="printableArea">
			<?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<section class="tiket_box_area">
				<div class="row" style="display: flex;justify-content: center;align-items: center; margin-right: 0;">
					<div class="col-12 col-md-12">

						<div class="box-tiket">
							<div class="box-tiket2">
								<div class="head-tiket">
									<h1><?php echo e($transaction->subEvent->name); ?></h1>
									<p><?php echo e(\Carbon\Carbon::parse($transaction->subEvent->date)->format('l, d F Y')); ?></p>
									<p><?php echo e(\Carbon\Carbon::parse($transaction->subEvent->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($transaction->subEvent->end_time)->format('H:i')); ?></p>
								</div>
								<div class="body-tiket">
									<div class="row">
										<div class="col-md-10">
											<div class="row">
												<div class="col-md-3">
													<div class="kode">
														<p>TIKET</p>
														<p>#<?php echo e($data->id); ?></p>
													</div>
												</div>
												<div class="col-md-3">
													<div class="kode">
														<p>PEMBELI</p>
														<p><?php echo e($data->owner); ?></p>
													</div>
												</div>
												<div class="col-md-3">
													<div class="kode">
														<p>JENIS TIKET</p>
														<p><?php echo e($data->type); ?></p>
													</div>
												</div>
												<div class="col-md-3">
													<div class="kode">
														<p>ORGANISASI</p>
														<p><?php echo e($transaction->subEvent->organization->name); ?></p>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-9">
													<div class="kode lok">
														<p>LOKASI</p>
														<p><?php echo e($transaction->subEvent->location); ?></p>
													</div>
												</div>
												<div class="col-md-3" style="display: flex;justify-content: center;align-items: center;">
													<img src="<?php echo e(asset('client/img/logo/logo.png')); ?>" class="logo">
												</div>
											</div>
										</div>
										<div class="col-md-2 qr" style="display: flex;justify-content: center;align-items: center;">
											<img src="<?php echo e(asset('client/img/icon/qr-kode.png')); ?>">
										</div>
								</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</section>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

			<script type="text/javascript">
				function printDiv(divName) {
					 var printContents = document.getElementById(divName).innerHTML;
					 var originalContents = document.body.innerHTML;

					 document.body.innerHTML = printContents;

					 window.print();

					 document.body.innerHTML = originalContents;
				}
			</script>

		<?php endif; ?>

						<br><br>
	<!--================End Order Details Area =================-->

<?php echo $__env->make('partial/_guest_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('client/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/stellar.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/lightbox/simpleLightbox.min.js')); ?>"></script>
<!-- <script src="vendors/lightbox/lightbox-plus-jquery.min.js"></script> -->
<script src="<?php echo e(asset('client/vendors/nice-select/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/isotope/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/isotope/isotope-min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('client/vendors/counter-up/jquery.waypoints.min.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('client/vendors/flipclock/timer.js')); ?>"></script> -->
<script src="<?php echo e(asset('client/vendors/counter-up/jquery.counterup.js')); ?>"></script>
<script src="<?php echo e(asset('client/js/mail-script.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('client/js/theme.js')); ?>"></script> -->
<script type="text/javascript">
$(document).ready(function () {
// Set the date we're counting down to
var countDownDate = new Date("<?php echo \Carbon\Carbon::parse($transaction->countdown)->format('M d, Y H:i:s'); ?>").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  // Output the result in an element with id="demo"
  // document.getElementById("getting-started").innerHTML = days + "d " + hours + "h "
  // + minutes + "m " + seconds + "s ";
   document.getElementById("waktu_pembayaran").innerHTML = hours + ":"
  + minutes + ":" + seconds;

  // If the count down is over, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("waktu_pembayaran").innerHTML = "KADALUARSA";
  }
}, 1000);
});
</script>
