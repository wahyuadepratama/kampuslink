<?php echo $__env->make('partial/_admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <!---
          START - Breadcrumbs
          -------------------->
          <ul class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(url('organization/'. $organization->instagram)); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <span>Event</span>
            </li>
            <li class="breadcrumb-item">
              <span>Event Detail (<?php echo e($sub_event->name); ?>)</span>
            </li>
          </ul>
          <!--
          END - Breadcrumbs
          -------------------->

          <div class="container">
            <div class="row" style="margin: 2%">
              <div class="col-sm-12">
                <div class="element-wrapper">
                  <div class="element-box">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="support-ticket-info">
                          <!-- <a class="close-ticket-info" href="#"><i class="os-icon os-icon-ui-23"></i></a> -->
                          <div class="support-ticket-content-header" style="margin-bottom:5%">
                            <h3 class="ticket-header">
                              <?php echo e($sub_event->name); ?>

                            </h3>
                          </div>
                          <div class="customer" style="text-align:center;">
                            <div class="row">
                              <div class="col-md-8">
                                <img src="<?php echo e(asset('storage/poster/_large/'. $sub_event->photo)); ?>" class="form-control">
                              </div>

                              <div class="col-md-4">
                                  <img src="<?php echo e(asset('storage/qr/event/'. $sub_event->qr_code)); ?>" class="form-control">
                                  <small>Scan QR Code for more information</small>
                              </div>
                            </div>
                          </div><br>
                          <div class="info-section text-left">
                            <div class="table-responsive">
                              <table class="table table-lightborder">
                                <tbody>
                                  <tr>
                                    <td style="vertical-align:top">Deskripsi</td>
                                    <td><?php echo $sub_event->description; ?></td>
                                  </tr>
                                  <tr>
                                    <td>Kategori</td>
                                    <td>
                                      <?php $sub_event_category = \App\Models\EventCategory::where('sub_event_id', $sub_event->id)->get(); ?>
                                      <?php $__currentLoopData = $sub_event_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="badge badge-primary">
                                          <?php echo e($key->category->name); ?>

                                        </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                  <tr>
                                  <tr>
                                    <td>Tanggal</td>
                                    <td><?php echo e(\Carbon\Carbon::parse($sub_event->date)->format('l, d F Y')); ?></td>
                                  </tr>
                                  <tr>
                                    <td>Waktu</td>
                                    <td><?php echo e(\Carbon\Carbon::parse($sub_event->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($sub_event->end_time)->format('H:i')); ?></td>
                                  </tr>
                                  <tr>
                                    <td>WhatsApp</td>
                                    <td><?php echo e($sub_event->whatsapp); ?></td>
                                  </tr>
                                  <tr>
                                    <td>Line</td>
                                    <td><?php echo e($sub_event->line); ?></td>
                                  </tr>
                                  <tr>
                                    <td>Web</td>
                                    <td><?php echo e($sub_event->web_link); ?></td>
                                  </tr>
                                  <tr>
                                    <td>Lokasi</td>
                                    <td><?php echo e($sub_event->location); ?></td>
                                  </tr>
                                  <tr>
                                    <td>Status</td>
                                    <td>
                                      <?php if($sub_event->approved == '0'): ?>
                                      <div class="badge badge-warning">
                                        Pending
                                      </div>
                                      <?php elseif($sub_event->approved == 1): ?>
                                      <div class="badge badge-success">
                                        Approved
                                      </div>
                                      <?php elseif($sub_event->approved == 2): ?>
                                      <div class="badge badge-danger">
                                        Ditolak
                                      </div>
                                      <?php endif; ?>
                                    </td>
                                  </tr>
                                  <?php if(isset($sub_event->reason)): ?>
                                  <tr>
                                    <td style="vertical-align:top">Alasan Penolakan</td>
                                    <td>
                                      <?php echo $sub_event->reason; $id = \Crypt::encryptString($sub_event->id);?><br><br><br>
                                      <a href="<?php echo e(url('organization/'. $organization->instagram .'/event/edit/'. $id)); ?>" class="btn btn-warning">Edit Event</a>
                                    </td>
                                  </tr>
                                  <?php endif; ?>
                                </tbody>
                              </table>
                            </div><br>

                            <?php if($sub_event->approved == 1): ?>
                            <h5 class="info-header text-left">
                              Peserta Terdaftar
                            </h5><br>
                            <div class="info-section">
                              <ul class="users-list as-tiles">
                                <?php $transaction = \App\Models\Transaction::where('sub_event_id', $sub_event->id)->where('status','Pembayaran Berhasil')->get(); ?>
                                <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php $ticketMember = \App\Models\Ticket::where('transaction_id', $list->id)->get(); ?>
                                  <div class="row">
                                  <?php $__currentLoopData = $ticketMember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="col-md-4">
                                    <div class="users-list-w">
                                      <div class="user-w with-status status-green">
                                        <div class="user-avatar-w">
                                          <div class="user-avatar">
                                            <img alt="" src="<?php echo e(asset('storage/avatar/user.png')); ?>">
                                          </div>
                                        </div>
                                        <div class="user-name">
                                          <h6 class="user-title">
                                            <?php echo e($ticket->owner); ?>

                                          </h6>
                                          <div class="user-role">
                                            Tiket <?php echo e($ticket->type); ?>

                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                              <?php if(count($transaction) == 0): ?>
                              <p>Belum ada peserta terdaftar!</p>
                              <?php endif; ?>
                            </div>
                            <?php endif; ?>

                        </div>
                      </div>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

      </div>

    </div>

    <?php echo $__env->make('partial/_admin_script_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </body>
</html>
